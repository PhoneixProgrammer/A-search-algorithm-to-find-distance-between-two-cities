#File:       Hfns.py

#Purpose:    Contains function objects for the A* search method.
#            h_zero returns a zero as a h function
#            h_east_west estimates a distance based on longitude
import math

class H_zero:
    def name(self):
        return "h=0"

    def h(self, long1, long2, lat1, lat2):
        return 0

class H_east_west:
    def name(self):
        return "h=east-west distance"

    def h(self, long1, long2, lat1, lat2):
        return 78.7 * abs((long1) - (long2))

class H_north_south:
    def name(self):
        return "h= north-south/latitude distance"

    def h(self, long1, long2, lat1, lat2):
        return 78.4 * abs((lat1) - (lat2))

class H_Haversine:
    def name(self):
        return "h= Straight line distance"

    def h(self, long1, long2, lat1, lat2):
        # distance between latitudes and longitudes 
        dLat = (lat2 - lat1) * math.pi / 180.0
        dLon = (long2 - long1) * math.pi / 180.0
  
        # convert to radians 
        lat1 = (lat1) * math.pi / 180.0
        lat2 = (lat2) * math.pi / 180.0
  
        # apply formulae 
        a = (pow(math.sin(dLat / 2), 2) + pow(math.sin(dLon / 2), 2) * 
             math.cos(lat1) * math.cos(lat2)); 
        rad = 6371
        c = 2 * math.asin(math.sqrt(a)) 
        return rad * c