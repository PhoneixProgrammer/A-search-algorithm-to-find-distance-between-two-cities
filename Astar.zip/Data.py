import sys 
def data():
    fixed = {}
    lis=['']
    def convert(lst):
        return ([i for item in lst for i in item.split()])
    
    france_long_file = open("france-latlong.txt", 'r', encoding = 'utf-8')
    for line in france_long_file:
        line = line.split('#', 1)[0]# Ignoring the lines starting with#
        line = line.rstrip()
            #print(line)
        listDetails = line.rstrip('\n').split(',')# I got here each word in list as 3 strings-'Angoulême', ' Nouvelle-Aquitaine', ' France 45.650002 0.160000'
            #print(listDetails)
        if listDetails!=lis:
            del listDetails[1]
        #print(listDetails)
        if listDetails!= lis:
            final=convert(listDetails)
            fixed[final[0]] = {"lat": float(final[2])}
            fixed[final[0]].update({"long": float(final[3])})
    return fixed